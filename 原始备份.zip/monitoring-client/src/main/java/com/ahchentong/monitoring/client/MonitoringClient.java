package com.ahchentong.monitoring.client;

import com.ahchentong.monitoring.client.util.SendUDPUtils;

public class MonitoringClient {
    public static void main(String[] args) {
        SendUDPUtils.send();
    }
}
