package com.ahchentong.monitoring.client.util.ssh;

import com.ahchentong.monitoring.client.util.ReadProperties;
import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class SshPublic {
    //private static Session session;
    /**
     * 连接服务器
     */
    public Session connect() {
        ReadProperties readProperties = new ReadProperties();
        Properties read = readProperties.read();
        Session session;
        JSch jsch = new JSch();
        try {
            session = jsch.getSession(
                    read.getProperty("local.username"),
                    read.getProperty("local.host"),
                    Integer.parseInt(read.getProperty("local.port"))
            );
            session.setPassword(read.getProperty("local.password"));

            System.out.println("SshPublic信息：");
            System.out.println(read.getProperty("local.username"));
            System.out.println(read.getProperty("local.host"));
            System.out.println(Integer.parseInt(read.getProperty("local.port")));
            System.out.println(read.getProperty("local.password"));

            Properties config = new Properties();
            config.put("StrictHostKeyChecking", "no");
            session.setConfig(config);
            session.connect();
        } catch (JSchException e) {
            e.printStackTrace();
            System.out.println("connect error !");
            return null;
        }
        return session;
    }

    public StringBuffer execute(Session session,String command){
//        System.out.println(command);
        ChannelExec channelExec = null;
        InputStream inputStream = null;
        try {
            channelExec = (ChannelExec) session.openChannel("exec");
            inputStream = channelExec.getInputStream();
            channelExec.setCommand(command);
            channelExec.connect();
            byte[] bit = new byte[1024];
            StringBuffer stringBuffer = new StringBuffer();
            while (inputStream.read(bit) > 0) {
                stringBuffer.append(new String(bit));
            }
            return stringBuffer;
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (channelExec != null && channelExec.isConnected()){
                channelExec.disconnect();
            }
            if (inputStream != null){
                try {
                    inputStream.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            disconnect(session);
        }
        return new StringBuffer("");
    }

    /**
     * 关闭服务器
     */
    public void disconnect(Session session) {
        if (session != null) {
            session.disconnect();
        }
    }
}
