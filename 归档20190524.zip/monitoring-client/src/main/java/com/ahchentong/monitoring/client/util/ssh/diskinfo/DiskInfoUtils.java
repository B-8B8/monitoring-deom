package com.ahchentong.monitoring.client.util.ssh.diskinfo;

import com.ahchentong.monitoring.client.util.ssh.SshPublic;
import com.jcraft.jsch.Session;

public class DiskInfoUtils {
    public static String getInfo(){
        SshPublic sshPublic = new SshPublic();
        Session session = sshPublic.connect();
        StringBuffer buffer = sshPublic.execute(session, "df -h");
        sshPublic.disconnect(session);
        return buffer.toString();
    }
}
